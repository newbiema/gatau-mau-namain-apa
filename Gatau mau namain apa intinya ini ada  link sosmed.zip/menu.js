alert("Selamat Datang di website saya :)")
//menampilkan waktu di website
function tampilkanWaktu() {
    var sekarang = new Date(); // Membuat objek Date

    var jam = sekarang.getHours();
    var menit = sekarang.getMinutes();
    var detik = sekarang.getSeconds();

    // Menambahkan nol di depan angka jika hanya satu digit
    if (jam < 10) {
        jam = "0" + jam;
    }
    if (menit < 10) {
        menit = "0" + menit;
    }
    if (detik < 10) {
        detik = "0" + detik;
    }

    // Menampilkan waktu pada elemen dengan id "waktu"
    document.getElementById("waktu").innerHTML = jam + ":" + menit + ":" + detik;

    // Mengulangi pembaruan waktu setiap detik
    setTimeout(tampilkanWaktu, 1000);
}